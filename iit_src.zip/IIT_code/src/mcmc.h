#ifndef BVSR_MCMC
#define BVSR_MCMC

#include "readin.h"
#include "output.h"
#include "model.h"


void mcmc(void);

#endif 

