#! /bin/sh


#./iit -m test_data/test2.mat -p test_data/test.ph -w 0 -s 100000 -o test_out/try2 -r 34 --g-exp 3 --start 1 --kappa 1 -t --ha 0.3 --true test_data/test.true
#./iit -m test_data/test2.mat -p test_data/test.ph -w 0 -s 100000 -o test_out/try3 -r 34 --g-exp 3 --start 1 --kappa 1 -t --hf 1 --true test_data/test.true
#./iit -m test_data/test2.mat -p test_data/test.ph -w 0 -s 100000 -o test_out/try4 -r 34 --g-exp 3 --start 1 --kappa 1 -t --hf 2 --true test_data/test.true
#./iit -m test_data/test2.mat -p test_data/test.ph -w 0 -s 100000 -o test_out/try5 -r 34 --g-exp 3 --start 1 --kappa 1 -t --hf 3 --true test_data/test.true
#./iit -m test_data/test2.mat -p test_data/test.ph -w 0 -s 100000 -o test_out/try6 -r 34 --g-exp 3 --start 1 --kappa 1 -t --ha 0.5 --true test_data/test.true
#./iit -m test_data/test2.mat -p test_data/test.ph -w 0 -s 100000 -o test_out/try7 -r 34 --g-exp 3 --start 1 --kappa 1 -t --ha 0.3 --hf 1 --true test_data/test.true
#./iit -m test_data/test2.mat -p test_data/test.ph -w 0 -s 100000 -o test_out/try8 -r 34 --g-exp 3 --start 1 --kappa 1 -t --ha 0.3 --hf 2 --true test_data/test.true
#./iit-linux -m test_data/test2.mat -p test_data/test.ph -w 0 -s 100000 -o test_out/try9 -r 34 --g-exp 3 --start 1 --kappa 1 -t --ha 0.3 --hf 3 --true test_data/test.true
